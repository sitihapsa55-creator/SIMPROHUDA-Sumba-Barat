# SIMPROHUDA v1

Prototype web aplikasi Sistem Informasi Monitoring Produk Hukum Daerah.

## Cara menjalankan
1. Ekstrak folder `SIMPROHUDA_v1`.
2. Buka folder tersebut.
3. Klik dua kali `index.html`.
4. Aplikasi akan terbuka di Google Chrome/Edge.

## Fitur
- Dashboard jumlah Perda/Perbup dan status tahapan.
- Tahapan: Penyusunan, Review, Harmonisasi, Pembahasan, Finalisasi, Selesai.
- Timeline mulai, target selesai, tanggal selesai.
- Tambah/edit/hapus produk hukum.
- Upload informasi berkas pada produk hukum.
- Pencarian produk hukum dan dokumen.
- Simulasi hak akses Admin, Perancang/Petugas, Pimpinan, Pemrakarsa.
- Data tersimpan sementara di localStorage browser.

## Catatan penting
Versi 1 adalah prototype client-side. File yang dipilih pada upload belum disimpan sebagai file permanen di server; metadata file dicatat di browser. Untuk penggunaan kantor yang sesungguhnya, versi berikutnya sebaiknya menggunakan database + backend + penyimpanan dokumen + login yang aman.
