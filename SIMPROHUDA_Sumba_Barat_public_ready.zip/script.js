const STORAGE_KEY = "simprohuda_v1_products";
const DOC_KEY = "simprohuda_v1_documents";

const stages = ["Penyusunan","Review","Harmonisasi","Pembahasan","Finalisasi","Selesai"];

const seedProducts = [
  {
    id: 1, type:"Perda", number:"3", year:2026,
    title:"Pajak Daerah dan Retribusi Daerah",
    owner:"Badan Pendapatan Daerah",
    start:"2026-08-01", target:"2026-09-15", finish:"",
    stage:"Harmonisasi", notes:"Menunggu hasil harmonisasi.",
  },
  {
    id: 2, type:"Perbup", number:"12", year:2026,
    title:"Tata Kelola Pelayanan Administrasi Pemerintahan",
    owner:"Bagian Organisasi",
    start:"2026-08-05", target:"2026-09-05", finish:"",
    stage:"Review", notes:"",
  },
  {
    id: 3, type:"Perda", number:"5", year:2026,
    title:"Anggaran Pendapatan dan Belanja Daerah Tahun Anggaran 2027",
    owner:"BPKAD",
    start:"2026-07-01", target:"2026-08-20", finish:"",
    stage:"Pembahasan", notes:"Pembahasan bersama DPRD.",
  },
  {
    id: 4, type:"Perbup", number:"8", year:2026,
    title:"Pedoman Penyusunan Produk Hukum Daerah",
    owner:"Bagian Hukum",
    start:"2026-06-10", target:"2026-07-30", finish:"2026-07-28",
    stage:"Selesai", notes:"Telah ditetapkan.",
  },
  {
    id: 5, type:"Perbup", number:"15", year:2026,
    title:"Standar Pelayanan Minimal Perangkat Daerah",
    owner:"Bappeda",
    start:"2026-08-12", target:"2026-10-10", finish:"",
    stage:"Penyusunan", notes:"",
  }
];

const seedDocs = [
  {id:101, productId:1, name:"Draft Perda Pajak Daerah.pdf", stage:"Penyusunan", date:"2026-08-01", size:"1.2 MB"},
  {id:102, productId:1, name:"Hasil Review.pdf", stage:"Review", date:"2026-08-07", size:"840 KB"},
  {id:103, productId:1, name:"Berkas Harmonisasi.pdf", stage:"Harmonisasi", date:"2026-08-15", size:"2.1 MB"},
  {id:104, productId:3, name:"Draft APBD 2027.docx", stage:"Pembahasan", date:"2026-08-10", size:"1.8 MB"},
  {id:105, productId:4, name:"Perbup Final.pdf", stage:"Selesai", date:"2026-07-28", size:"980 KB"}
];

let products = load(STORAGE_KEY, seedProducts);
let documents = load(DOC_KEY, seedDocs);

const $ = (id) => document.getElementById(id);

function load(key, fallback){
  try{
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  }catch(e){ return fallback; }
}
function save(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
  localStorage.setItem(DOC_KEY, JSON.stringify(documents));
}
function esc(value=""){
  return String(value).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
function formatDate(date){
  if(!date) return "-";
  return new Date(date+"T00:00:00").toLocaleDateString("id-ID",{day:"2-digit",month:"short",year:"numeric"});
}
function daysDiff(date){
  const target = new Date(date+"T23:59:59");
  const today = new Date();
  return Math.ceil((target-today)/86400000);
}
function statusOf(p){
  if(p.stage==="Selesai") return {text:"Selesai", cls:"success"};
  const d = daysDiff(p.target);
  if(d < 0) return {text:"Terlambat", cls:"danger"};
  if(d <= 7) return {text:"Mendekati Target", cls:"warning"};
  return {text:"Berjalan", cls:""};
}
function progress(p){
  const idx = stages.indexOf(p.stage);
  return Math.round(((idx+1)/stages.length)*100);
}
function productLabel(p){
  return `${p.type} No. ${p.number}/${p.year}`;
}
function showToast(msg){
  const el=$("toast"); el.textContent=msg; el.classList.add("show");
  setTimeout(()=>el.classList.remove("show"),2600);
}

function renderDashboard(){
  const counts = Object.fromEntries(stages.map(s=>[s,0]));
  products.forEach(p=>counts[p.stage]++);
  const total=products.length;
  const perda=products.filter(p=>p.type==="Perda").length;
  const perbup=products.filter(p=>p.type==="Perbup").length;

  const statData=[
    ["Total Produk",total,""],
    ["Perda",perda,""],
    ["Perbup",perbup,""],
    ["Dalam Proses",products.filter(p=>p.stage!=="Selesai").length,""],
    ["Mendekati Target",products.filter(p=>statusOf(p).cls==="warning").length,"warning"],
    ["Selesai",counts.Selesai,"success"]
  ];
  $("statsGrid").innerHTML=statData.map(([l,v,c])=>`
    <div class="stat-card"><span class="stat-label"><i class="stat-dot ${c}"></i>${l}</span><div class="stat-value">${v}</div></div>
  `).join("");

  $("stageBars").innerHTML=stages.map(s=>{
    const n=counts[s], pct=total ? Math.round(n/total*100):0;
    return `<div class="stage-row"><span>${s}</span><div class="bar-bg"><div class="bar-fill" style="width:${pct}%"></div></div><strong>${n}</strong></div>`;
  }).join("");

  const attention=products.filter(p=>p.stage!=="Selesai").sort((a,b)=>new Date(a.target)-new Date(b.target)).slice(0,5);
  $("attentionList").innerHTML=attention.length ? attention.map(p=>{
    const st=statusOf(p), d=daysDiff(p.target);
    return `<div class="attention-item"><div><div class="attention-title">${esc(productLabel(p))}</div><div class="attention-sub">${esc(p.title)}</div></div><div class="deadline ${st.cls}">${d<0?Math.abs(d)+" hari terlambat":d+" hari lagi"}</div></div>`;
  }).join("") : `<div class="empty-state">Tidak ada produk yang perlu perhatian.</div>`;

  $("recentTable").innerHTML=products.slice().sort((a,b)=>b.id-a.id).slice(0,5).map(p=>{
    const st=statusOf(p);
    return `<tr><td><strong>${esc(p.type)}</strong></td><td>${esc(p.number)}/${esc(p.year)}</td><td class="product-name">${esc(p.title)}</td><td><span class="badge">${esc(p.stage)}</span></td><td>${formatDate(p.target)}</td><td><span class="badge ${st.cls}">${st.text}</span></td></tr>`;
  }).join("");
}

function renderProducts(){
  const q=($("productSearch").value||"").toLowerCase();
  const type=$("typeFilter").value;
  const stage=$("stageFilter").value;
  const filtered=products.filter(p=>{
    const hay=[p.type,p.number,p.year,p.title,p.owner,p.stage].join(" ").toLowerCase();
    return (!q||hay.includes(q))&&(!type||p.type===type)&&(!stage||p.stage===stage);
  });
  $("productTable").innerHTML=filtered.length ? filtered.map(p=>{
    const st=statusOf(p);
    return `<tr>
      <td><div class="product-name">${esc(productLabel(p))}</div><div class="muted">${esc(p.title)}</div></td>
      <td>${esc(p.owner)}</td>
      <td><span class="badge">${esc(p.stage)}</span><div class="muted">${progress(p)}% progres</div></td>
      <td class="timeline"><div class="muted">${formatDate(p.start)} → ${formatDate(p.target)}</div><div class="timeline-line"><div class="timeline-fill" style="width:${progress(p)}%"></div></div></td>
      <td><span class="badge ${st.cls}">${st.text}</span></td>
      <td><div class="action-group"><button class="small-btn" onclick="editProduct(${p.id})">Edit</button><button class="small-btn" onclick="viewProduct(${p.id})">Detail</button><button class="small-btn" onclick="deleteProduct(${p.id})">Hapus</button></div></td>
    </tr>`;
  }).join("") : `<tr><td colspan="6"><div class="empty-state">Data tidak ditemukan.</div></td></tr>`;
}

function renderDocuments(){
  const q=($("docSearch").value||"").toLowerCase();
  const stage=$("docStageFilter").value;
  const filtered=documents.filter(d=>{
    const p=products.find(x=>x.id===d.productId);
    const hay=[d.name,d.stage,p?.title||"",p?.number||""].join(" ").toLowerCase();
    return (!q||hay.includes(q))&&(!stage||d.stage===stage);
  });
  $("documentList").innerHTML=filtered.length ? filtered.map(d=>{
    const p=products.find(x=>x.id===d.productId);
    return `<div class="document-card"><div class="file-icon">PDF</div><div style="flex:1"><h4>${esc(d.name)}</h4><p>${esc(productLabel(p||{type:"",number:"-",year:""}))} • ${esc(d.stage)} • ${formatDate(d.date)} • ${esc(d.size||"")}</p></div><button class="small-btn" onclick="showToast('Mode prototype: file dapat dihubungkan pada versi database/server.')">Lihat</button></div>`;
  }).join("") : `<div class="empty-state">Belum ada dokumen yang sesuai.</div>`;
}

function globalSearch(){
  const q=($("globalSearch").value||"").trim().toLowerCase();
  if(!q){$("searchResults").innerHTML=`<div class="empty-state">Masukkan kata kunci untuk memulai pencarian.</div>`;return;}
  const ps=products.filter(p=>[p.type,p.number,p.year,p.title,p.owner,p.stage].join(" ").toLowerCase().includes(q));
  const ds=documents.filter(d=>{
    const p=products.find(x=>x.id===d.productId);
    return [d.name,d.stage,p?.title||"",p?.number||""].join(" ").toLowerCase().includes(q);
  });
  let html="";
  ps.forEach(p=>html+=`<div class="search-result"><h4>📄 ${esc(productLabel(p))} — ${esc(p.title)}</h4><p>${esc(p.owner)} • Tahap ${esc(p.stage)} • Target ${formatDate(p.target)}</p></div>`);
  ds.forEach(d=>html+=`<div class="search-result"><h4>📎 ${esc(d.name)}</h4><p>${esc(d.stage)} • ${formatDate(d.date)}</p></div>`);
  $("searchResults").innerHTML=html||`<div class="empty-state">Tidak ada hasil untuk “${esc(q)}”.</div>`;
}

function openModal(id=null){
  $("productModal").classList.add("show");
  $("productForm").reset();
  $("editId").value="";
  $("formYear").value=2026;
  $("formStart").value=new Date().toISOString().slice(0,10);
  $("formStage").value="Penyusunan";
  $("modalTitle").textContent=id ? "Edit Produk Hukum" : "Tambah Produk Hukum";
  if(id){
    const p=products.find(x=>x.id===id); if(!p)return;
    $("editId").value=p.id;$("formType").value=p.type;$("formNumber").value=p.number;
    $("formYear").value=p.year;$("formOwner").value=p.owner;$("formTitle").value=p.title;
    $("formStart").value=p.start;$("formTarget").value=p.target;$("formFinish").value=p.finish||"";
    $("formStage").value=p.stage;$("formNotes").value=p.notes||"";
  }
}
function closeModal(){$("productModal").classList.remove("show")}
function editProduct(id){openModal(id)}
function deleteProduct(id){
  const p=products.find(x=>x.id===id); if(!p)return;
  if(confirm(`Hapus ${productLabel(p)}?`)){
    products=products.filter(x=>x.id!==id);
    documents=documents.filter(x=>x.productId!==id);
    save();renderAll();showToast("Produk hukum berhasil dihapus.");
  }
}
function viewProduct(id){
  const p=products.find(x=>x.id===id);if(!p)return;
  const docs=documents.filter(d=>d.productId===id);
  alert(`${productLabel(p)}\n\n${p.title}\n\nTahap: ${p.stage}\nProgres: ${progress(p)}%\nMulai: ${formatDate(p.start)}\nTarget: ${formatDate(p.target)}\nSelesai: ${formatDate(p.finish)}\n\nDokumen: ${docs.length} berkas\n\nKeterangan: ${p.notes||"-"}`);
}
function handleForm(e){
  e.preventDefault();
  const file=$("formFile").files[0];
  const id=$("editId").value;
  const obj={
    id:id?Number(id):Date.now(),
    type:$("formType").value,number:$("formNumber").value.trim(),year:Number($("formYear").value),
    owner:$("formOwner").value.trim(),title:$("formTitle").value.trim(),
    start:$("formStart").value,target:$("formTarget").value,finish:$("formFinish").value,
    stage:$("formStage").value,notes:$("formNotes").value.trim()
  };
  if(id) products=products.map(p=>p.id===obj.id?obj:p);
  else products.push(obj);
  if(file){
    documents.unshift({id:Date.now()+1,productId:obj.id,name:file.name,stage:obj.stage,date:new Date().toISOString().slice(0,10),size:formatBytes(file.size)});
  }
  save();closeModal();renderAll();showToast(id?"Produk hukum diperbarui.":"Produk hukum berhasil ditambahkan.");
}
function formatBytes(bytes){
  if(!bytes)return "0 KB";
  const units=["B","KB","MB","GB"];let i=0,n=bytes;
  while(n>=1024&&i<units.length-1){n/=1024;i++}
  return `${n.toFixed(i?1:0)} ${units[i]}`;
}

function goPage(page){
  document.querySelectorAll(".page").forEach(x=>x.classList.remove("active-page"));
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("active"));
  $("page-"+page).classList.add("active-page");
  const btn=document.querySelector(`.nav-item[data-page="${page}"]`);
  if(btn)btn.classList.add("active");
  const titles={dashboard:["Dashboard","Monitoring Produk Hukum Daerah secara terpusat"],produk:["Produk Hukum","Kelola Perda dan Perbup beserta progresnya"],dokumen:["Dokumen","Pusat dokumen produk hukum berdasarkan tahapan"],pencarian:["Pencarian","Cari produk hukum dan dokumen secara cepat"],pengguna:["Pengguna","Hak akses pengguna berdasarkan kewenangan"]};
  $("pageTitle").textContent=titles[page][0];$("pageSubtitle").textContent=titles[page][1];
  $("sidebar").classList.remove("open");
  if(page==="dashboard")renderDashboard();
  if(page==="produk")renderProducts();
  if(page==="dokumen")renderDocuments();
}

function renderAll(){renderDashboard();renderProducts();renderDocuments();}

document.querySelectorAll(".nav-item").forEach(btn=>btn.addEventListener("click",()=>goPage(btn.dataset.page)));
document.querySelectorAll("[data-go]").forEach(btn=>btn.addEventListener("click",()=>goPage(btn.dataset.go)));
$("quickAddBtn").addEventListener("click",()=>openModal());
$("addProductBtn").addEventListener("click",()=>openModal());
$("closeModal").addEventListener("click",closeModal);
$("cancelModal").addEventListener("click",closeModal);
$("productModal").addEventListener("click",e=>{if(e.target===$("productModal"))closeModal()});
$("productForm").addEventListener("submit",handleForm);
$("productSearch").addEventListener("input",renderProducts);
$("typeFilter").addEventListener("change",renderProducts);
$("stageFilter").addEventListener("change",renderProducts);
$("docSearch").addEventListener("input",renderDocuments);
$("docStageFilter").addEventListener("change",renderDocuments);
$("globalSearch").addEventListener("input",globalSearch);
$("menuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
$("roleSelect").addEventListener("change",e=>{$("currentRole").textContent=e.target.value;showToast("Peran tampilan diubah ke "+e.target.value+".")});
$("today").textContent=new Date().toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"});

renderAll();
